# sign_firmware.py
import argparse
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend
import os

def load_private_key(path):
    with open(path, "rb") as f:
        return serialization.load_pem_private_key(f.read(), password=None, backend=default_backend())

def sign_file(private_key, file_path, sig_out):
    with open(file_path, "rb") as f:
        data = f.read()
    signature = private_key.sign(
        data,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )
    with open(sig_out, "wb") as s:
        s.write(signature)
    print(f"Signature written to: {sig_out}")

if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Sign a firmware file with RSA private key (detached signature).")
    p.add_argument("--key", "-k", required=False, default="keys/private_key.pem", help="Path to private key PEM")
    p.add_argument("--infile", "-i", required=True, help="Firmware file to sign")
    p.add_argument("--out", "-o", required=False, help="Output signature file (default: infile.sig)")

    args = p.parse_args()
    sigfile = args.out if args.out else args.infile + ".sig"
    if not os.path.exists(args.key):
        raise SystemExit(f"Private key not found: {args.key}. Run gen_keys.py first.")
    private_key = load_private_key(args.key)
    sign_file(private_key, args.infile, sigfile)
