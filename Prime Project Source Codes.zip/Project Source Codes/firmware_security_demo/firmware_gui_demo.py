# firmware_gui_verify.py
import tkinter as tk
from tkinter import filedialog, messagebox
import hashlib
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.exceptions import InvalidSignature
import os

def sha256_of_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def load_public_key(path):
    with open(path, "rb") as f:
        return serialization.load_pem_public_key(f.read())

def verify_signature(public_key, file_path, sig_path):
    with open(file_path, "rb") as f:
        data = f.read()
    with open(sig_path, "rb") as s:
        signature = s.read()
    try:
        public_key.verify(
            signature,
            data,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        return True
    except InvalidSignature:
        return False

class App:
    def __init__(self, root):
        self.root = root
        root.title("Firmware Integrity & Signature Verification")
        root.geometry("700x420")
        self.orig_path = None
        self.mod_path = None
        self.sig_path = None
        self.pubkey_path = None
        self.public_key = None

        # --- buttons and labels ---
        tk.Label(root, text="1) Select Original Firmware (signed)", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=10, pady=(10,0))
        frame1 = tk.Frame(root); frame1.pack(fill="x", padx=10)
        tk.Button(frame1, text="Select Original", command=self.select_original).pack(side="left")
        self.orig_label = tk.Label(frame1, text="No file selected", anchor="w")
        self.orig_label.pack(side="left", padx=10)

        tk.Label(root, text="2) Select Modified Firmware (to compare)", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=10, pady=(10,0))
        frame2 = tk.Frame(root); frame2.pack(fill="x", padx=10)
        tk.Button(frame2, text="Select Modified", command=self.select_modified).pack(side="left")
        self.mod_label = tk.Label(frame2, text="No file selected", anchor="w")
        self.mod_label.pack(side="left", padx=10)

        tk.Label(root, text="3) Select Signature File (.sig)", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=10, pady=(10,0))
        frame3 = tk.Frame(root); frame3.pack(fill="x", padx=10)
        tk.Button(frame3, text="Select Signature", command=self.select_signature).pack(side="left")
        self.sig_label = tk.Label(frame3, text="No signature selected", anchor="w")
        self.sig_label.pack(side="left", padx=10)

        tk.Label(root, text="4) Select Public Key (PEM)", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=10, pady=(10,0))
        frame4 = tk.Frame(root); frame4.pack(fill="x", padx=10)
        tk.Button(frame4, text="Select Public Key", command=self.select_pubkey).pack(side="left")
        self.pub_label = tk.Label(frame4, text="No public key selected", anchor="w")
        self.pub_label.pack(side="left", padx=10)

        # action buttons
        action_frame = tk.Frame(root); action_frame.pack(fill="x", padx=10, pady=15)
        tk.Button(action_frame, text="Compute & Compare Hashes", command=self.compare_hashes, bg="#f0f0f0").pack(side="left")
        tk.Button(action_frame, text="Verify Signature", command=self.verify_sig, bg="#f0f0f0").pack(side="left", padx=10)
        tk.Button(action_frame, text="Clear", command=self.clear_all, bg="#f0f0f0").pack(side="left")

        # results
        res_frame = tk.Frame(root); res_frame.pack(fill="both", expand=True, padx=10, pady=10)
        self.hash_result = tk.Label(res_frame, text="Hash comparison result will appear here.", anchor="w", justify="left")
        self.hash_result.pack(fill="x")
        self.sig_result = tk.Label(res_frame, text="Signature verification result will appear here.", anchor="w", justify="left")
        self.sig_result.pack(fill="x", pady=(8,0))

        # instruction
        inst = ("Instructions:\n"
                "1) Generate RSA keys using gen_keys.py (private -> sign, public -> verify).\n"
                "2) Sign original firmware with sign_firmware.py to create a .sig file.\n"
                "3) Use 'Compute & Compare Hashes' to check integrity (original vs modified).\n"
                "4) Use 'Verify Signature' to validate authenticity using the public key.\n")
        tk.Label(root, text=inst, anchor="w", justify="left", fg="#333").pack(fill="x", padx=10, pady=(6,10))

    def select_original(self):
        path = filedialog.askopenfilename(title="Select Original Firmware (signed)")
        if path:
            self.orig_path = path
            self.orig_label.config(text=os.path.basename(path))

    def select_modified(self):
        path = filedialog.askopenfilename(title="Select Modified Firmware (to compare)")
        if path:
            self.mod_path = path
            self.mod_label.config(text=os.path.basename(path))

    def select_signature(self):
        path = filedialog.askopenfilename(title="Select Signature File (.sig)")
        if path:
            self.sig_path = path
            self.sig_label.config(text=os.path.basename(path))

    def select_pubkey(self):
        path = filedialog.askopenfilename(title="Select Public Key (PEM)", filetypes=[("PEM files","*.pem"),("All files","*.*")])
        if path:
            self.pubkey_path = path
            self.pub_label.config(text=os.path.basename(path))
            # load public key now for speed
            try:
                self.public_key = load_public_key(path)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load public key: {e}")
                self.public_key = None

    def compare_hashes(self):
        if not self.orig_path or not self.mod_path:
            messagebox.showwarning("Missing files", "Select both original and modified firmware files first.")
            return
        h1 = sha256_of_file(self.orig_path)
        h2 = sha256_of_file(self.mod_path)
        text = f"Original SHA-256: {h1}\nModified SHA-256: {h2}\n\n"
        if h1 == h2:
            self.hash_result.config(text=text + "Result: HASHES MATCH — No integrity change detected.", fg="green")
        else:
            self.hash_result.config(text=text + "Result: HASH MISMATCH — Integrity compromised.", fg="red")

    def verify_sig(self):
        if not (self.orig_path and self.sig_path and self.public_key):
            messagebox.showwarning("Missing inputs", "Ensure original firmware, signature (.sig) and public key are selected.")
            return
        ok = verify_signature(self.public_key, self.orig_path, self.sig_path)
        if ok:
            self.sig_result.config(text="Signature Verification: VALID — firmware is authentic.", fg="green")
        else:
            self.sig_result.config(text="Signature Verification: INVALID — firmware authenticity FAILED.", fg="red")

    def clear_all(self):
        self.orig_path = self.mod_path = self.sig_path = self.pubkey_path = None
        self.public_key = None
        self.orig_label.config(text="No file selected")
        self.mod_label.config(text="No file selected")
        self.sig_label.config(text="No signature selected")
        self.pub_label.config(text="No public key selected")
        self.hash_result.config(text="Hash comparison result will appear here.", fg="black")
        self.sig_result.config(text="Signature verification result will appear here.", fg="black")


if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
