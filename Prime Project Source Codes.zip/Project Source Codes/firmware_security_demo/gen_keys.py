# gen_keys.py
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
import os

KEY_DIR = "keys"
os.makedirs(KEY_DIR, exist_ok=True)

# Generate private key
private_key = rsa.generate_private_key(
    public_exponent=65537,
    key_size=4096
)

# Serialize and save private key (PEM)
priv_pem = private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.TraditionalOpenSSL,
    encryption_algorithm=serialization.NoEncryption()  # No password for demo; for production use a passphrase
)
with open(os.path.join(KEY_DIR, "private_key.pem"), "wb") as f:
    f.write(priv_pem)

# Generate and save public key
public_key = private_key.public_key()
pub_pem = public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo
)
with open(os.path.join(KEY_DIR, "public_key.pem"), "wb") as f:
    f.write(pub_pem)

print("RSA key pair generated in './keys/'")
print(" - private_key.pem  (KEEP SECRET)")
print(" - public_key.pem   (can be shared)")
