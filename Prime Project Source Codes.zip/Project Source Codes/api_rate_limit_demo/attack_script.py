import requests
import time

url = "http://127.0.0.1:5000/"

print("Simulating attacker...")
for i in range(10):
    r = requests.get(url)
    print(f"Request {i+1}: {r.status_code} - {r.text}")
    time.sleep(0.3)  # small delay to show progression
