from flask import Flask, jsonify
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)

# Set rate limit: 5 requests per minute per client IP
limiter = Limiter(
    key_func=get_remote_address,
    app=app,
    default_limits=["5 per minute"]
)

@app.route("/")
def home():
    return jsonify({
        "message": "Welcome to Prime Technologies API!",
        "note": "This endpoint allows 5 requests per minute."
    })

# Handle rate limiting (429 Too Many Requests)
@app.errorhandler(429)
def ratelimit_handler(e):
    return jsonify({
        "error": "Too Many Requests",
        "message": "You have exceeded the allowed request limit. Slow down!"
    }), 429

if __name__ == "__main__":
    print("API Rate Limiting Demo running at http://127.0.0.1:5000/")
    app.run(debug=True)


#Open http://127.0.0.1:5000/ in browser after running this program